# configs/examples

Example and starting-point configuration files. **None of these files are loaded by the gateway automatically.** They are reference material — copy and modify them when the scenario fits, then activate using the instructions in each file's header.

## Files

### `mvp_policy.yaml` — Full production governance bundle

**Scenario:** You want explicit, versioned rule files for all governance layers instead of the default add-on symlink system. Provides full `stop_on` control including `require_attribution`, `require_approval`, `rate_limit`, and `quarantine`.

**How to activate:** Push via the admin API to replace the active bundle, or copy to `$MVGC_POLICIES_DIR/bundle.yaml` and reload. The `files:` entries in this bundle reference rule files that already exist at `configs/policies/` (`targets.yaml`, `credential-rules.yaml`, `budgets.yaml`, `risk.yaml`) — those files stay where they are.

**Does NOT replace individual rule files.** Only the bundle descriptor moves; the per-layer YAML files remain in `configs/policies/`.

---

### `proxy-credentials.yaml` — Single-bundle proxy credential routing

**Scenario:** You want all credential-to-host routing consolidated in one self-contained file — no add-on symlinks, no separate rule files. Useful when you need to override default credential IDs, restrict which providers are reachable, or manage routing as a single atomic unit.

**How to activate:** Edit the `select_credential:` values to match your actual `credential_id` entries, then push via the admin API to replace the active bundle, or copy to `$MVGC_POLICIES_DIR/bundle.yaml` and reload. All rules are `inline_rules` — no external files needed.

**Replaces `bundle.yaml` entirely** while active. The add-on symlink system is inactive when this bundle is loaded.

---

### `proxy-mitm.yaml` — MITM transparent proxy bundle

**Scenario:** Full transparent MITM (man-in-the-middle) proxy mode where the gateway intercepts and inspects HTTPS traffic. Required when clients connect to AI providers using their native SDKs without a base URL override — the gateway terminates TLS using a local CA, applies policy to the decrypted request, then re-encrypts to the upstream.

**Prerequisites — all required before activating:**
- Proxy mode enabled (the default: `proxy_enabled: true`)
- The CA certificate distributed to and trusted by all client machines (auto-generated on first start; install with `mvgc-gateway install`)
- Client traffic routed through the gateway (system proxy settings or network-level redirect)

**How to activate:** Edit `managed_domains` and `bypass_domains` for your environment, then push via the admin API or copy to `$MVGC_POLICIES_DIR/bundle.yaml` and reload.

**MITM is active automatically when proxy mode is enabled.** The gateway auto-generates a CA on first start and intercepts CONNECT tunnels to managed domains.

See [docs/external/guides/network-ops.md](../../docs/external/guides/network-ops.md) for the full transparent proxy setup guide.

---

### `transforms.yaml` — Custom request transforms override

**Scenario:** You want to change, disable, or extend the default request mutations that the gateway applies before forwarding to upstream providers (header injection, path normalization).

**Default behaviour (no action needed for most deployments):** The gateway binary embeds two default transforms — `X-MVGC-Request-ID` header injection and `/v1/` path normalization — and applies them automatically. You only need this file if you want to override those defaults.

**How to activate:** This is a **rule file**, not a bundle — it cannot be pushed via the admin API on its own.
1. Copy to `$MVGC_POLICIES_DIR/transforms.yaml`
2. Add `transforms.yaml` to the `files:` list in your active bundle (e.g. `mvp_policy.yaml`)
3. Reload or re-push the bundle

**When this file is loaded, it fully replaces the embedded defaults.** Include any transforms you still want (the file ships with both defaults pre-populated as a starting point).
